package com.myapp.capstone.service;
 
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;
 
import java.util.Arrays;
import java.util.List;
import java.util.Optional;
 
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.boot.test.context.SpringBootTest;
 
import com.myapp.capstone.model.Agent;
import com.myapp.capstone.model.DisplayAgent;
import com.myapp.capstone.repository.AgentRepository;
import com.myapp.capstone.repository.DisplayAgentRepository;

@SpringBootTest
@ExtendWith(MockitoExtension.class)
class DisplayAgentServiceTest {
 
    @Mock
    private AgentRepository agentRepository;
 
    @Mock
    private DisplayAgentRepository displayAgentRepository;
 
    @InjectMocks
    private DisplayAgentService displayAgentService;
 
    private Agent agent;
    private DisplayAgent displayAgent;
 
    @BeforeEach
    void setUp() {
        agent = new Agent();
        agent.setEmail("test@example.com");
        agent.setName("Test Agent");
 
        displayAgent = new DisplayAgent();
        displayAgent.setEmail(agent.getEmail());
        displayAgent.setName(agent.getName());
        displayAgent.setRole("Agent");
        displayAgent.setAutoAssigned(false);
    }
 
    @Test
    void addAgentToDisplayAgents_success() {
        when(agentRepository.findByEmail("test@example.com")).thenReturn(agent);
 
        String result = displayAgentService.addAgentToDisplayAgents("test@example.com");
 
        assertEquals("Email successfully added to display_agents table", result);
        verify(displayAgentRepository).save(any(DisplayAgent.class)); // Check that save was called
    }
 
    @Test
    void addAgentToDisplayAgents_agentNotFound() {
        when(agentRepository.findByEmail("notfound@example.com")).thenReturn(null);
 
        String result = displayAgentService.addAgentToDisplayAgents("notfound@example.com");
 
        assertEquals("Agent with email notfound@example.com not found.", result);
        verify(displayAgentRepository, never()).save(any(DisplayAgent.class)); // Ensure save was not called
    }
 
    @Test
    void getAllDisplayAgents() {
        when(displayAgentRepository.findAll()).thenReturn(Arrays.asList(displayAgent));
 
        List<DisplayAgent> agents = displayAgentService.getAllDisplayAgents();
 
        assertNotNull(agents);
        assertEquals(1, agents.size());
        assertEquals("Test Agent", agents.get(0).getName());
    }
 
    @Test
    void getDisplayAgentById_found() {
        when(displayAgentRepository.findById(1L)).thenReturn(Optional.of(displayAgent));
 
        DisplayAgent result = displayAgentService.getDisplayAgentById(1L);
 
        assertNotNull(result);
        assertEquals("Test Agent", result.getName());
    }
 
    @Test
    void getDisplayAgentById_notFound() {
        when(displayAgentRepository.findById(2L)).thenReturn(Optional.empty());
 
        DisplayAgent result = displayAgentService.getDisplayAgentById(2L);
 
        assertNull(result);
    }
}
 
 