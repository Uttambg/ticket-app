package com.myapp.capstone.service;
 
import static org.junit.jupiter.api.Assertions.*;

import static org.mockito.Mockito.*;
 
import org.junit.jupiter.api.BeforeEach;

import org.junit.jupiter.api.Test;

import org.mockito.InjectMocks;

import org.mockito.Mock;

import org.mockito.MockitoAnnotations;
 
import com.myapp.capstone.model.UserDetails;

import com.myapp.capstone.repository.UserRepo;
 
public class UserServiceTest {
 
    @InjectMocks

    private UserService userService;
 
    @Mock

    private UserRepo userRepository;
 
    private UserDetails user;
 
    @BeforeEach

    public void setUp() {

        MockitoAnnotations.openMocks(this);

        user = new UserDetails();

        user.setEmail("test@example.com");

        user.setPassword("password");

        user.setName("Test User");

        user.setRole("USER");

    }
 
    @Test

    public void testAddUser_Success() {

        // Mock the repository to return null when searching for the existing user

        when(userRepository.findByEmail(user.getEmail())).thenReturn(null);

        when(userRepository.save(user)).thenReturn(user);
 
        // Call the method under test

        UserDetails result = userService.addUser(user);
 
        // Verify the result and interactions

        assertNotNull(result);

        assertEquals(user.getEmail(), result.getEmail());

        verify(userRepository).findByEmail(user.getEmail());

        verify(userRepository).save(user);

    }
 
    @Test

    public void testAddUser_UserAlreadyExists() {

        // Mock the repository to return an existing user

        when(userRepository.findByEmail(user.getEmail())).thenReturn(user);
 
        // Call the method under test and assert exception is thrown

        RuntimeException exception = assertThrows(RuntimeException.class, () -> {

            userService.addUser(user);

        });
 
        assertEquals("User already exists with email: " + user.getEmail(), exception.getMessage());

        verify(userRepository).findByEmail(user.getEmail());

        verify(userRepository, never()).save(any());

    }

}

 