package com.myapp.capstone.service;

import com.myapp.capstone.model.Agent;
import com.myapp.capstone.model.Ticket;
import com.myapp.capstone.repository.AgentRepository;
import com.myapp.capstone.repository.TicketRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.boot.test.context.SpringBootTest;

import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@SpringBootTest
class AdminServiceImplTest {

    private TicketRepository ticketRepository;
    private AgentRepository agentRepository;
    private AdminServiceImpl adminService;

    @BeforeEach
    void setUp() {
        ticketRepository = mock(TicketRepository.class);
        agentRepository = mock(AgentRepository.class);
        adminService = new AdminServiceImpl(ticketRepository, agentRepository);
    }

    @Test
    void assignAgent_Success() {
        // Given
        String ticketId = "ticket123";
        Long agentId = 1L;

        Ticket ticket = new Ticket();
        ticket.setId(ticketId);
        ticket.setStatus("NEW");

        Agent agent = new Agent();
        agent.setId(agentId);

        when(ticketRepository.findById(ticketId)).thenReturn(Optional.of(ticket));
        when(agentRepository.findById(agentId)).thenReturn(Optional.of(agent));
        when(ticketRepository.save(ticket)).thenReturn(ticket);

        // When
        Ticket updatedTicket = adminService.assignAgentToTicket(ticketId, agentId);

        // Then
        assertNotNull(updatedTicket);
        assertEquals(agent, updatedTicket.getAgent());
        assertEquals("IN PROGRESS", updatedTicket.getStatus());

        verify(ticketRepository, times(1)).save(ticket);
    }

    @Test
    void assignAgent_TicketNotFound() {
        // Given
        String ticketId = "ticket123";
        Long agentId = 1L;

        when(ticketRepository.findById(ticketId)).thenReturn(Optional.empty());

        // When & Then
        RuntimeException thrown = assertThrows(
                RuntimeException.class,
                () -> adminService.assignAgentToTicket(ticketId, agentId)
        );

        assertEquals("Ticket not found", thrown.getMessage());
    }

    @Test
    void assignAgent_AgentNotFound() {
        // Given
        String ticketId = "ticket123";
        Long agentId = 1L;

        Ticket ticket = new Ticket();
        ticket.setId(ticketId);
        ticket.setStatus("NEW");

        when(ticketRepository.findById(ticketId)).thenReturn(Optional.of(ticket));
        when(agentRepository.findById(agentId)).thenReturn(Optional.empty());

        // When & Then
        RuntimeException thrown = assertThrows(
                RuntimeException.class,
                () -> adminService.assignAgentToTicket(ticketId, agentId)
        );

        assertEquals("Agent not found", thrown.getMessage());
    }

    @Test
    void assignAgent_TicketAlreadyInProgress() {
        // Given
        String ticketId = "ticket123";
        Long agentId = 1L;

        Ticket ticket = new Ticket();
        ticket.setId(ticketId);
        ticket.setStatus("IN PROGRESS");

        Agent agent = new Agent();
        agent.setId(agentId);

        when(ticketRepository.findById(ticketId)).thenReturn(Optional.of(ticket));
        when(agentRepository.findById(agentId)).thenReturn(Optional.of(agent));
        when(ticketRepository.save(ticket)).thenReturn(ticket);

        // When
        Ticket updatedTicket = adminService.assignAgentToTicket(ticketId, agentId);

        // Then
        assertNotNull(updatedTicket);
        assertEquals(agent, updatedTicket.getAgent());
        assertEquals("IN PROGRESS", updatedTicket.getStatus());

        verify(ticketRepository, times(1)).save(ticket);
    }
}
