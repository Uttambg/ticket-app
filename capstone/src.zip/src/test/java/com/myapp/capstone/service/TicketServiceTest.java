package com.myapp.capstone.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.boot.test.context.SpringBootTest;

import com.myapp.capstone.model.Message;
import com.myapp.capstone.model.Ticket;
import com.myapp.capstone.model.UserDetails;
import com.myapp.capstone.model.dto.MessageDto;
import com.myapp.capstone.model.dto.TicketDto;
import com.myapp.capstone.repository.MessageRepository;
import com.myapp.capstone.repository.TicketRepository;
import com.myapp.capstone.repository.UserRepo;

@SpringBootTest
@ExtendWith(MockitoExtension.class)
class TicketServiceTest {

    @InjectMocks
    private TicketService ticketService;

    @Mock
    private TicketRepository ticketRepository;

    @Mock
    private MessageRepository messageRepository;

    @Mock
    private UserRepo userRepository;
    
    @Mock
    private TicketDto ticketdto;

    private UserDetails user;
    private Ticket ticket;
    private Message message;

    @BeforeEach
    void setUp() {
        user = new UserDetails();
        user.setId(1L);
        user.setEmail("test@example.com");

        ticket = new Ticket();
        ticket.setId("ticketId");
        ticket.setSubject("Test Ticket");
        ticket.setPriority("HIGH");
        ticket.setStatus("NEW");
        ticket.setUser(user);
        ticket.setMessages(new ArrayList<>());

        message = new Message();
        message.setId(1L);
        message.setContent("Test Message");
        message.setTicket(ticket);
    }

    @Test
    void createTicket_shouldCreateAndReturnTicketDto() {
        TicketDto ticketDto = new TicketDto();
        ticketDto.setSubject("Test Ticket");
        ticketDto.setPriority("HIGH");
        ticketDto.setUserId(1L);
        ticketDto.setMessages(new ArrayList<>());

        when(userRepository.findById(1L)).thenReturn(Optional.of(user));
        when(ticketRepository.save(any(Ticket.class))).thenReturn(ticket);

        TicketDto result = ticketService.createTicket(ticketDto);

        assertNotNull(result);
        assertEquals("Test Ticket", result.getSubject());
        assertEquals("HIGH", result.getPriority());
        assertEquals(1L, result.getUserId()); 
        verify(ticketRepository, times(1)).save(any(Ticket.class));
        
    }

    @Test
    void getAllTickets_shouldReturnListOfTicketDtos() {
        when(ticketRepository.findAll()).thenReturn(List.of(ticket));

        List<TicketDto> result = ticketService.getAllTickets();

        assertNotNull(result);
        assertEquals(1, result.size());
        assertEquals("Test Ticket", result.get(0).getSubject());
    }

    @Test
    void getTicketById_shouldReturnTicketDto_whenTicketExists() {
        when(ticketRepository.findById("ticketId")).thenReturn(Optional.of(ticket));

        Optional<TicketDto> result = ticketService.getTicketById("ticketId");

        assertTrue(result.isPresent());
        assertEquals("Test Ticket", result.get().getSubject());
    }

    @Test
    void updateTicket_shouldUpdateAndReturnTicketDto() {
        TicketDto updatedTicketDto = new TicketDto();
        updatedTicketDto.setStatus("CLOSED");

        when(ticketRepository.findById("ticketId")).thenReturn(Optional.of(ticket));
        when(ticketRepository.save(any(Ticket.class))).thenReturn(ticket);

        TicketDto result = ticketService.updateTicket("ticketId", updatedTicketDto);

        assertNotNull(result);
        assertEquals("CLOSED", result.getStatus());
    }

    @Test
    void deleteTicket_shouldDeleteTicket_whenExists() {
        when(ticketRepository.existsById("ticketId")).thenReturn(true);

        ticketService.deleteTicket("ticketId");

        verify(ticketRepository, times(1)).deleteById("ticketId");
    }

    @Test
    void deleteTicket_shouldThrowException_whenNotFound() {
        when(ticketRepository.existsById("ticketId")).thenReturn(false);

        RuntimeException thrown = assertThrows(RuntimeException.class, () -> {
            ticketService.deleteTicket("ticketId");
        });

        assertEquals("Ticket not found", thrown.getMessage());
    }

    @Test
    void addMessageToTicket_shouldAddMessageAndReturnMessageDto() {
        MessageDto messageDto = new MessageDto();
        messageDto.setContent("New Message");

        when(ticketRepository.findById("ticketId")).thenReturn(Optional.of(ticket));
        when(messageRepository.save(any(Message.class))).thenReturn(message);

        MessageDto result = ticketService.addMessageToTicket("ticketId", messageDto);

        assertNotNull(result);
        assertEquals("New Message", result.getContent());
        verify(messageRepository, times(1)).save(any(Message.class));
    }

    @Test
    void getMessagesForTicket_shouldReturnListOfMessages() {
        ticket.getMessages().add(message);
        when(ticketRepository.findById("ticketId")).thenReturn(Optional.of(ticket));

        List<MessageDto> result = ticketService.getMessagesForTicket("ticketId");

        assertNotNull(result);
        assertEquals(1, result.size());
        assertEquals("Test Message", result.get(0).getContent());
    }
    
    @Test
    public void getTicketsByUserId_success() {
        when(ticketRepository.findByUser_Id(1L)).thenReturn(Arrays.asList(ticket));
 
        List<TicketDto> result = ticketService.getTicketsByUserId(1L);
 
        assertNotNull(result);
        assertEquals(1, result.size());
        assertEquals("Test Ticket", result.get(0).getSubject());
    }
}
