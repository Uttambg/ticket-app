package com.myapp.capstone.service;
 
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import com.myapp.capstone.model.Message;
import com.myapp.capstone.repository.MessageRepository;
import jakarta.persistence.EntityNotFoundException;
 
public class MessageServiceTest {
 
    @InjectMocks

    private MessageService messageService;
 
    @Mock

    private MessageRepository messageRepository;
 
    private Message message;
 
    @BeforeEach

    public void setUp() {

        MockitoAnnotations.openMocks(this);

        message = new Message();

        message.setId(1L);

        message.setContent("Test message");

    }
 
    @Test

    public void testGetMessageById_Success() {

        // Mock the repository to return the message when searching for its ID

        when(messageRepository.findById(1L)).thenReturn(java.util.Optional.of(message));
 
        // Call the method under test

        Message result = messageService.getMessageById(1L);
 
        // Verify the result and interactions

        assertNotNull(result);

        assertEquals(message.getContent(), result.getContent());

        verify(messageRepository).findById(1L);

    }
 
    @Test

    public void testGetMessageById_NotFound() {

        // Mock the repository to return an empty Optional for a non-existent ID

        when(messageRepository.findById(2L)).thenReturn(java.util.Optional.empty());
 
        // Call the method under test and assert exception is thrown

        EntityNotFoundException exception = assertThrows(EntityNotFoundException.class, () -> {

            messageService.getMessageById(2L);

        });
 
        assertEquals("Message not found with id: 2", exception.getMessage());

        verify(messageRepository).findById(2L);

    }

}

 