package com.myapp.capstone.model.dto;
 
public class EmailDto {
    private String email;
 
    // Getters and Setters
    public String getEmail() {
        return email;
    }
 
    public void setEmail(String email) {
        this.email = email;
    }
}