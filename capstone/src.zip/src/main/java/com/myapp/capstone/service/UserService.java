package com.myapp.capstone.service;
 
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.myapp.capstone.model.UserDetails;
import com.myapp.capstone.repository.UserRepo;
 
@Service
public class UserService {

	@Autowired
	private UserRepo userRepository;

	public UserDetails addUser(UserDetails userDetails) {

        // Check if a user with the same email (or username) already exists

		 UserDetails existingUser = userRepository.findByEmail(userDetails.getEmail());
 
        if (existingUser!=null) {
            // Handle the case where the user already exists (return null, throw exception, etc.)
            throw new RuntimeException("User already exists with email: " + userDetails.getEmail());
        }
        // Save the new user to the database
        return userRepository.save(userDetails);

    }
 
}

 