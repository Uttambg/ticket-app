package com.myapp.capstone.service;
import org.springframework.stereotype.Service;
import com.myapp.capstone.model.Agent;
import com.myapp.capstone.model.Ticket;
import com.myapp.capstone.repository.AgentRepository;
import com.myapp.capstone.repository.TicketRepository;
import com.myapp.capstone.service.AdminService;
@Service
public class AdminServiceImpl implements AdminService {
    private final TicketRepository ticketRepository;
    private final AgentRepository agentRepository;
    public AdminServiceImpl(TicketRepository ticketRepository, AgentRepository agentRepository) {
        this.ticketRepository = ticketRepository;
        this.agentRepository = agentRepository;
    }
    @Override
    public Ticket assignAgentToTicket(String ticketId, Long agentId) {
        // Fetch the ticket by ID
        Ticket ticket = ticketRepository.findById(ticketId)
                .orElseThrow(() -> new RuntimeException("Ticket not found"));
 
        // Fetch the agent by ID
        Agent agent = agentRepository.findById(agentId)
                .orElseThrow(() -> new RuntimeException("Agent not found"));
 
        // Assign the agent to the ticket
        ticket.setAgent(agent);
 
        // Update the ticket status to "ASSIGNED"
        ticket.setStatus("InProgress");
        ticket.setAssignedAgent(agent.getName());
        // Save the updated ticket
        return ticketRepository.save(ticket);
    }

}
