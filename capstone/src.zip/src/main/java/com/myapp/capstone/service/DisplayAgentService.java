package com.myapp.capstone.service;
 
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
 
import com.myapp.capstone.model.Agent;
import com.myapp.capstone.model.DisplayAgent;
import com.myapp.capstone.repository.AgentRepository;
import com.myapp.capstone.repository.DisplayAgentRepository;
 
import java.util.List;
import java.util.Optional;
 
@Service
public class DisplayAgentService {
 
    @Autowired
    private AgentRepository agentRepository;
 
    @Autowired
    private DisplayAgentRepository displayAgentRepository;
 
    // Method for adding an agent to display_agents
    public String addAgentToDisplayAgents(String email) {
        // Fetch the agent by email
        Agent agent = agentRepository.findByEmail(email);
 
        // If agent is null, return a failure message
        if (agent == null) {
            return "Agent with email " + email + " not found.";
        }
        
        DisplayAgent existingDisplayAgent = displayAgentRepository.findByEmail(email);
        
        if (existingDisplayAgent != null) {
            return "Agent with email " + email + " is already in display_agents table.";
        }
 
        // Create a new DisplayAgent and set its details from the found agent
        DisplayAgent displayAgent = new DisplayAgent();
        displayAgent.setId(agent.getId());
        displayAgent.setEmail(agent.getEmail());
        displayAgent.setName(agent.getName());
        displayAgent.setRole("Agent"); // Set default role
        displayAgent.setAutoAssigned(false); // Set default autoAssigned value
 
        // Save the DisplayAgent to the display_agents table
        displayAgentRepository.save(displayAgent);
 
        return "Email successfully added to display_agents table";
    }
 
    // Method to retrieve all display agents
    public List<DisplayAgent> getAllDisplayAgents() {
        return displayAgentRepository.findAll();
    }
 
    // Method to retrieve a display agent by ID
    public DisplayAgent getDisplayAgentById(Long id) {
        Optional<DisplayAgent> displayAgent = displayAgentRepository.findById(id);
        return displayAgent.orElse(null); // Return the agent if found, otherwise null
    }
}
 
 