package com.myapp.capstone.model.dto; // swarup

public class LoginResponse {
	private String token;
	private String role;
	private Long userId; // Changed userId to Long

	public LoginResponse(String token, String role, Long userId) { // Updated constructor
		this.token = token;
		this.role = role;
		this.userId = userId; // Initialize userId
	}

	public LoginResponse(String token) {
		// TODO Auto-generated constructor stub
		this.token = token;

	}

	public String getToken() {
		return token;
	}

	public void setToken(String token) {
		this.token = token;
	}

	public String getRole() {
		return role;
	}

	public void setRole(String role) {
		this.role = role;
	}

	public Long getUserId() { // Updated return type to Long
		return userId;
	}

	public void setUserId(Long userId) { // Updated parameter type to Long
		this.userId = userId;
	}
}
