import React, { useState, useEffect } from 'react';
import { fetchTicketDetails, fetchAllAgents, updateTicket } from '../api/apiClient';
import AgentInfoDropdown from './AgentInfoDropdown';
import { DisplayAgent } from '../types/Ticket';
 
interface TicketInfoProps {
  id: string; // ID prop passed from TicketDetails
}
 
const TicketInfo: React.FC<TicketInfoProps> = ({ id }) => {
  const [ticket, setTicket] = useState<any>(null);
  const [status, setStatus] = useState('Open');
  const [priority, setPriority] = useState('Medium');
 
  const [isAssigned, setIsAssigned] = useState(false);
  const [showAssignmentSection, setShowAssignmentSection] = useState(false);
  const [agents, setAgents] = useState<DisplayAgent[]>([]);
  const [selectedAgent, setSelectedAgent] = useState<DisplayAgent | null>(null);
 
  useEffect(() => {
    const loadTicketDetails = async () => {
      try {
        const ticketData = await fetchTicketDetails(id);
        setTicket(ticketData);
        setStatus(ticketData.status);
        setPriority(ticketData.priority);
      } catch (error) {
        alert("Failed to fetch ticket details.");
      }
    };
 
    if (id) {
      loadTicketDetails();
    }
  }, [id]);
 
  const handleStatusChange = async (e: React.ChangeEvent<HTMLSelectElement>) => {
    const newStatus = e.target.value;
    setStatus(newStatus);
 
    try {
      await updateTicket(id, { status: newStatus, priority, messages: null });
      alert('Ticket status updated successfully!');
    } catch (error) {
      alert('Failed to update ticket status.');
    }
  };
 
  const handlePriorityChange = async (e: React.ChangeEvent<HTMLSelectElement>) => {
    const newPriority = e.target.value;
    setPriority(newPriority);
 
    try {
      await updateTicket(id, { status, priority: newPriority, messages: null });
      alert('Ticket priority updated successfully!');
    } catch (error) {
      alert('Failed to update ticket priority.');
    }
  };
 
  const loadAgents = async () => {
    try {
      const agentsList = await fetchAllAgents();
      if (Array.isArray(agentsList)) {
        console.log("Fetched agents data:", agentsList);
        setAgents(agentsList);
      } else {
        console.error("Fetched agents data is not an array:", agentsList);
        setAgents([]);
      }
    } catch (error) {
      console.error('Failed to fetch agents:', error);
      setAgents([]);
    }
  };
 
  useEffect(() => {
    if (showAssignmentSection) {
      loadAgents();
    }
  }, [showAssignmentSection]);
 
  const handleAgentSelection = (agent: DisplayAgent | null) => {
    setSelectedAgent(agent);
    setIsAssigned(!!agent);
    setShowAssignmentSection(false);
    alert(agent ? `Assignee changed to ${agent.name}` : "Assignee has been removed");
  };
 
  return (
    <div className="p-10 bg-gray-50 rounded-lg shadow-lg h-[100vh] overflow-y-auto">
      <h2 className="text-2xl mb-5 font-semibold">Ticket Details</h2>
 
      {ticket ? (
        <>
          <p className="my-2"><strong>Ticket ID:</strong> {ticket.id}</p>
          <p className="my-2"><strong>Created:</strong> {new Date(ticket.createdAt).toLocaleString()}</p>
          <p className="my-2"><strong>Last Message:</strong> {new Date(ticket.updatedAt).toLocaleString()}</p>
 
          <p className="my-2">
            <strong>Status:</strong>
            <select
              value={status}
              onChange={handleStatusChange}
              className="ml-3 p-1 rounded border border-gray-300 text-sm"
            >
              <option value="Open">Open</option>
              <option value="In Progress">In Progress</option>
              <option value="Closed">Closed</option>
            </select>
          </p>
 
          <p className="my-2">
            <strong>Priority:</strong>
            <select
              value={priority}
              onChange={handlePriorityChange}
              className="ml-3 p-1 rounded border border-gray-300 text-sm"
            >
              <option value="Low">Low</option>
              <option value="Medium">Medium</option>
              <option value="High">High</option>
            </select>
          </p>
 
          <div className="mt-5 p-4 bg-white rounded-lg shadow-md">
            <h3 className="text-lg font-semibold mb-3 flex items-center">
              Agent
              {!isAssigned && (
                <button
                  className="ml-2 text-blue-500 underline"
                  onClick={() => setShowAssignmentSection(true)}
                >
                  Assign
                </button>
              )}
            </h3>
 
            {isAssigned ? (
              <div className="flex flex-col items-start">
                <div className="flex items-center">
                  <div className="w-8 h-8 rounded-full bg-gray-300 flex items-center justify-center mr-2 text-white font-semibold">
                    {selectedAgent?.name.charAt(0).toUpperCase()}
                  </div>
                  <div>
                    <p>{selectedAgent?.name}</p>
                    <p className="text-xs">{selectedAgent?.email}</p>
                  </div>
                </div>
                <button
                  className="mt-3 bg-red-500 text-white py-2 px-4 rounded hover:bg-red-700"
                  onClick={() => handleAgentSelection(null)}
                >
                  Unassign
                </button>
              </div>
            ) : (
              <p className="text-gray-400">No agent assigned to this ticket.</p>
            )}
 
            {!isAssigned && showAssignmentSection && (
              <AgentInfoDropdown
                agents={agents}
                onSelect={handleAgentSelection}
                selectedAgent={selectedAgent}
                onClose={() => setShowAssignmentSection(false)}
              />
            )}
          </div>
        </>
      ) : (
        <p>Loading ticket details...</p>
      )}
    </div>
  );
};
 
export default TicketInfo;
 
 