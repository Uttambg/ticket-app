import React from 'react';

interface SuccessPopupProps {
  message: string;
}

const SuccessPopup: React.FC<SuccessPopupProps> = ({ message }) => {
  return (
    <div className="fixed inset-0 flex items-center justify-center bg-black bg-opacity-50 z-50">
      <div className="bg-white rounded-lg shadow-lg p-6 max-w-sm mx-auto">
        <div className="flex items-center">
          <svg
            className="w-6 h-6 text-green-500 mr-2"
            xmlns="http://www.w3.org/2000/svg"
            fill="none"
            viewBox="0 0 24 24"
            stroke="currentColor"
          >
            <path
              strokeLinecap="round"
              strokeLinejoin="round"
              strokeWidth={2}
              d="M9 12l2 2 4-4m1 4a8 8 0 10-8 8 8 8 0 008-8z"
            />
          </svg>
          <h2 className="text-xl font-semibold text-gray-800">Success!</h2>
        </div>
        <p className="mt-2 text-gray-600">{message}</p>
        <button
          className="mt-4 w-full px-4 py-2 text-sm font-medium text-white bg-blue-600 rounded-md hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500"
          onClick={() => window.location.reload()} // You can customize the action here
        >
          Close
        </button>
      </div>
    </div>
  );
};

export default SuccessPopup;
