import React from 'react';
import './SorryPage.css'; // Import the CSS file for styling

const SorryPage: React.FC = () => {
  return (
    <div className="sorry-container">
      <div className="background-animation"></div>

      <div className="text-content">
        <h1 className="sorry-text">Sorry, Sis!</h1>
        <p className="message">
          I didn't mean to hurt you. Please forgive me for what I did, you're the best sister anyone could ever have. ❤️
        </p>
      </div>

      <div className="heart-container">
        <div className="heart"></div>
        <div className="heart"></div>
        <div className="heart"></div>
      </div>
    </div>
  );
};

export default SorryPage;
