import React from 'react';

const Dash: React.FC = () => {
  return (
    <div>
      <h1>Hello</h1>
    </div>
  );
};

export default Dash;
