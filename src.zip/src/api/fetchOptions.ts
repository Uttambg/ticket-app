// src/api/fetchOptions.ts
export const fetchOptions = {
    headers: {
      'Content-Type': 'application/json',
    },
  };
  