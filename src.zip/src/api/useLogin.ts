// src/hooks/useLogin.ts
import { useState } from 'react';
import { login } from '../api/apiClient';
import { LoginRequest , LoginResponse } from '../types/Ticket';

export const useLogin = () => {
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  const handleLogin = async (credentials: LoginRequest): Promise<LoginResponse | void> => {
    setLoading(true);
    try {
      const response = await login(credentials);
      localStorage.setItem('token', response.token);
      localStorage.setItem('role', response.role);
      return response;
    } catch (err) {
      setError('Login failed');
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  return { handleLogin, error, loading };
};
