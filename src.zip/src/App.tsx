import React from 'react';
import { BrowserRouter as Router, Routes,Route } from 'react-router-dom';
import { Sidebar } from './components/Sidebar'; // Named import
import AppRoutes from './Routes'; // Import the routes component
import NewTicket from './components/NewTicket';
import Login from './components/Login';
 
const App = () => {
  return (
    <Router>
     
     
      <AppRoutes />

      <Routes>
      <Route path="/" element={<Login />} />
      <Route path="/sidebar" element={<Sidebar />} />
      <Route path="/new-ticket" element={<NewTicket />} />
      </Routes>
    </Router>
  );
};
 
export default App;
 
 